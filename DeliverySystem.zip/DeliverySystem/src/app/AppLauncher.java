package app;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.time.Duration;
import java.util.Arrays;

public class AppLauncher extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Создаем WebView для отображения карты
        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();

        // HTML с Yandex Map
        String yandexMapHTML = """
                <html>
                <head>
                <script type='text/javascript' src='https://api-maps.yandex.ru/2.1/?lang=ru_RU&apikey=ВАШ_API_КЛЮЧ'></script>
                <script type='text/javascript'>
                function init() {
                    var myMap = new ymaps.Map('map', {
                        center: [55.7558, 37.6176],
                        zoom: 10
                    });
                    var route = new ymaps.multiRouter.MultiRoute({
                        referencePoints: [
                            [55.7558, 37.6176],
                            [55.7510, 37.6173]
                        ],
                        params: { results: 1 }
                    });
                    myMap.geoObjects.add(route);
                }
                ymaps.ready(init);
                </script>
                </head>
                <body>
                <div id='map' style='width: 100%; height: 100%;'></div>
                </body>
                </html>
                """;

        // Загружаем карту
        webEngine.loadContent(yandexMapHTML);

        // Создаем интерфейс
        StackPane root = new StackPane();
        root.getChildren().add(webView);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Yandex Map Viewer");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Простая демонстрация бизнес-логики
        System.out.println("Демонстрация логики: создание заказа и доставки.");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
